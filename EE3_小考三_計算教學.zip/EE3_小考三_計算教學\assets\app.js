// ===== 公式 / 電路繪製 =====
window.renderMath = function (root) {
  const el = root || document;
  el.querySelectorAll('.math').forEach(function (node) {
    if (node.dataset.done) return;
    const src = node.textContent;
    try { if (window.katex) { katex.render(src, node, { throwOnError: false, displayMode: node.classList.contains('display') }); node.dataset.done = '1'; } }
    catch (e) { /* 沒有網路時保留原始 TeX */ }
  });
  el.querySelectorAll('.eq').forEach(function (node) {
    if (node.dataset.done) return;
    const src = node.textContent;
    try { if (window.katex) { katex.render(src, node, { throwOnError: false, displayMode: true }); node.dataset.done = '1'; } } catch (e) {}
  });
};

// ===== OpenForm 類型的電路圖繪製 =====
(function () {
  const S = 'var(--ink, #23272f)', P = 'var(--paper, #fff)';
  function L(x1, y1, x2, y2, w) { return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${S}" stroke-width="${w || 1.4}"/>`; }
  function Pth(d, w) { return `<path d="${d}" fill="none" stroke="${S}" stroke-width="${w || 1.4}"/>`; }
  function dot(x, y) { return `<circle cx="${x}" cy="${y}" r="3.2" fill="${S}"/>`; }
  function gl(x, y) { // ground
    return L(x, y, x, y + 8) + L(x - 9, y + 8, x + 9, y + 8, 1.6) + L(x - 6, y + 12, x + 6, y + 12, 1.4) + L(x - 3, y + 16, x + 3, y + 16, 1.2);
  }
  function res(x1, y1, x2, y2, label, vert) {
    const n = 6, t = [];
    if (vert) {
      const h = (y2 - y1), step = h / n;
      let d = `M${x1},${y1}`;
      for (let i = 1; i <= n; i++) d += ` L${x1 + (i % 2 ? 5 : -5)},${y1 + step * i}`;
      d += ` L${x1},${y2}`;
      t.push(Pth(d));
      if (label) t.push(`<text x="${x1 + 14}" y="${(y1 + y2) / 2 + 4}" font-size="12" font-style="italic" fill="${S}">${label}</text>`);
    } else {
      const w = (x2 - x1), step = w / n;
      let d = `M${x1},${y1}`;
      for (let i = 1; i <= n; i++) d += ` L${x1 + step * i},${y1 + (i % 2 ? -5 : 5)}`;
      d += ` L${x2},${y2}`;
      t.push(Pth(d));
      if (label) t.push(`<text x="${(x1 + x2) / 2}" y="${y1 - 9}" font-size="12" font-style="italic" text-anchor="middle" fill="${S}">${label}</text>`);
    }
    return t.join('');
  }
  function vsrc(x, ycen, label) { // 垂直電壓源
    return L(x, ycen - 26, x, ycen - 14) + `<circle cx="${x}" cy="${ycen}" r="14" fill="${P}" stroke="${S}" stroke-width="1.4"/>` +
      L(x - 5, ycen - 6, x + 5, ycen - 6, 1.1) + L(x - 9, ycen - 2, x + 9, ycen - 2, 1.1) + L(x - 5, ycen + 2, x + 5, ycen + 2, 1.1) +
      L(x, ycen + 14, x, ycen + 26) +
      `<text x="${x - 20}" y="${ycen + 4}" font-size="12" font-style="italic" text-anchor="middle" fill="${S}">${label}</text>` +
      `<text x="${x - 8}" y="${ycen - 16}" font-size="10" fill="${S}">+</text>`;
  }
  function cur(x, y1, y2, label) { // 電流箭頭（向上）
    return L(x, y1, x, y2 + 4, 1.1) + `<polygon points="${x},${y2 - 2} ${x - 4},${y2 + 4} ${x + 4},${y2 + 4}" fill="${S}"/>` +
      `<text x="${x + 8}" y="${(y1 + y2) / 2}" font-size="12" font-style="italic" fill="${S}">${label}</text>` +
      `<path d="M${x + 22},${y2 + 26} L${x + 22},${y1 + 40}" stroke="${S}" stroke-width="0.8" stroke-dasharray="3,3" marker-end="url(#arr)"/>` +
      dot(x, y1) + dot(x, y2 + 12);
  }
  function npn(x, y, flip) {
    // x,y = 射極引腳底部（基準點）；flip=true 表示集極朝下（NPN 倒過來）
    const by = y - 20, cx = x - 22;
    return Pth(`M${cx},${by} L${x - 22},${by}`) + L(x - 22, by - 9, x - 22, by + 9, 2.2) +
      Pth(`M${x - 22},${by} L${x},${by - 14} L${x},${by - 26}`) +
      Pth(`M${x - 22},${by} L${x},${by + 14} L${x},${by + 26}`) +
      `<polygon points="${x - 6},${by + 6} ${x - 4},${by + 15} ${x - 13},${by + 10}" fill="${S}"/>` +
      `<text x="${cx - 8}" y="${by + 4}" font-size="11" fill="${S}">B</text>`;
  }
  const defs = `<defs><marker id="arr" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto"><polygon points="0 0, 8 3, 0 6" fill="${S}"/></marker></defs>`;
  window.CIRC = { L, Pth, dot, gl, res, vsrc, cur, npn, defs };
})();

window.drawFigures = function () {
  const { L, Pth, dot, gl, res, vsrc, cur, npn, defs } = window.CIRC;
  const T = (x, y, s, sz, style) => `<text x="${x}" y="${y}" font-size="${sz || 12}" ${style || ''} fill="#23272f">${s}</text>`;
  const it = (x, y, s, a) => T(x, y, s, 12, `font-style="italic" ${a || ''}`);
  const fm = (x, y, s, a) => T(x, y, s, 11, `font-family="Georgia,serif" ${a || ''}`);
  const dash = (x1, y1, x2, y2) => `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#c4542d" stroke-width="1" stroke-dasharray="4,3"/>`;

  // ---------- Fig.1 非理想 op-amp 非反相放大器 ----------
  const w1 = `<svg viewBox="0 0 560 300" role="img" aria-labelledby="fig1t"><title id="fig1t">Fig.1 非理想運算放大器非反相放大器</title>
  ${defs}
  ${L(70, 30, 70, 240)}                     <!-- 輸入源支路 -->
  ${vsrc(70, 260 - 26 + 0, '')}
  ${L(70, 286, 70, 288)}${gl(70, 250)}
  ${res(70, 52, 70, 100, 'R', true)}
  ${L(70, 30, 240, 30)}${dot(150, 30)}${dot(70, 30)}
  ${cur(150, 46, 28, 'I')}
  ${Pth('M240,10 L330,45 L330,125 L240,160 Z', 1.6)}
  ${T(248, 62, '+', 16)}${T(248, 112, '−', 16)}
  ${it(262, 78, 'V', '')}${fm(274, 82, 'id', '')}${T(283, 92, '→', 10)}
  ${L(150, 60, 150, 30)}${gl(150, 60)}
  ${res(240, 52, 150, 52, 'R', false)}${T(194, 72, 'id', 10, `font-family="Georgia,serif"`)}
  ${dot(240, 84)}
  ${it(300, 78, 'μV', '')}${fm(322, 82, 'id', '')}
  ${res(150, 150, 240, 150, 'R', false)}${T(194, 170, '1', 10, `font-family="Georgia,serif"`)}
  ${L(150, 150, 150, 30)}${L(150, 150, 150, 196)}${gl(150, 196)}
  ${L(330, 85, 400, 85)}${dot(400, 85)}
  ${res(400, 85, 400, 150, 'r', true)}${T(414, 152, 'o', 10, `font-family="Georgia,serif"`)}
  ${L(400, 150, 400, 196)}${gl(400, 196)}
  ${L(400, 85, 485, 85)}${dot(485, 85)}
  ${Pth('M485,58 L440,75 L440,95 L485,112 Z', 1.4)}${T(474, 86, 'V', 12)}
  ${res(485, 85, 485, 160, 'R', true)}${T(499, 162, 'L', 10, `font-family="Georgia,serif"`)}
  ${L(485, 160, 485, 196)}${gl(485, 196)}
  ${L(485, 85, 485, 20)}${L(485, 20, 560, 20)}${L(400, 85, 400, 20)}${L(400, 20, 330, 20)}${L(330, 20, 330, 20)}
  ${res(330, 20, 400, 20, 'R', false)}${T(365, 40, '2', 10, `font-family="Georgia,serif"`)}
  ${L(330, 20, 330, 45)}
  ${dash(520, 8, 520, 130)}${Pth('M540,66 L526,60 L526,72 Z', 1.2)}${it(505, 40, 'R', 'text-anchor="middle"')}${fm(517, 44, 'out')}
  ${dash(96, 66, 232, 66)}
  ${it(64, 214, 'R', '')}${fm(76, 218, 's', '')}
  ${it(52, 268, 'V', '')}${fm(64, 272, 's', '')}
  ${T(30, 20, 'Fig.1：非反相（電壓串聯負回授）', 12, 'font-weight="600"')}
  </svg>`;

  // ---------- 區塊圖解 ----------
  const w2 = `<svg viewBox="0 0 560 170" role="img" aria-labelledby="fig1bt"><title id="fig1bt">回授方塊圖</title>${defs}
  ${it(16, 64, 'V', '')}${T(26, 68, '+', 10)}
  ${L(40, 72, 96, 72)}
  <circle cx="96" cy="72" r="13" fill="#fff" stroke="#23272f" stroke-width="1.4"/>
  ${T(90, 77, '+', 12)}${T(90, 94, '−', 12)}
  ${it(112, 62, 'V', '')}${T(122, 60, 'e', 10)}
  ${L(109, 72, 150, 72)}
  <rect x="150" y="46" width="96" height="52" rx="4" fill="#fbeee7" stroke="#c4542d" stroke-width="1.4"/>
  ${T(198, 70, 'A', 15, 'font-weight="600" text-anchor="middle"')}
  ${T(198, 88, '開回路增益', 10, 'text-anchor="middle"')}
  ${L(246, 72, 300, 72)}${dot(300, 72)}
  ${L(300, 72, 350, 72)}
  <rect x="350" y="46" width="86" height="52" rx="4" fill="#fff" stroke="#23272f" stroke-width="1.4"/>
  ${T(393, 78, 'R', 13, 'text-anchor="middle"')}${T(405, 82, 'L', 9, 'text-anchor="middle"')}
  ${it(470, 76, 'V', '')}${T(480, 74, 'o', 10)}
  ${L(300, 72, 300, 118)}${L(300, 118, 520, 118)}
  <rect x="440" y="96" width="54" height="44" rx="4" fill="#fff" stroke="#888" stroke-width="1.2" stroke-dasharray="4,3"/>
  ${T(467, 123, 'β', 12, 'text-anchor="middle"')}
  ${L(440, 118, 300, 118)}${dot(300, 118)}
  ${L(300, 118, 200, 118)}${L(200, 118, 200, 96)}
  <polygon points="200,90 194,100 206,100" fill="#23272f"/>
  <circle cx="200" cy="80" r="13" fill="#fff" stroke="#23272f" stroke-width="1.4"/>
  ${L(187, 80, 0, 80)}
  ${T(222, 140, 'β = R₁/(R₁+R₂)', 11)}
  </svg>`;

  // ---------- Fig.2 (a) ----------
  const w3 = `<svg viewBox="0 0 420 300" role="img" aria-labelledby="fig2t"><title id="fig2t">Fig.2 共射極，基極經 RB 接地，Rin 自集極看入</title>${defs}
  ${text}
  </svg>`;

  // ---------- π 模型 (a) ----------
  function piModel(x0, withRB, title) {
    const o = [];
    const X = x0;
    o.push(L(X, 40, X + 250, 40));                 // 集極（上）節點線
    o.push(L(X + 250, 40, X + 250, 70)); o.push(gl(X + 250, 70));
    o.push(res(X + 190, 40, X + 190, 96, 'r', true)); o.push(T(X + 204, 100, 'o', 10, 'font-family="Georgia,serif"'));
    o.push(L(X + 92, 40, X + 96, 130));             // 受控源與集極接點
    o.push(L(X + 96, 130, X + 92, 130));
    o.push(L(X + 96, 130, X, 130));                 // 射極節點線（左側）
    o.push(L(X + 250, 40, X + 250, 40));
    o.push(L(X, 130, X, 150)); o.push(gl(X, 150));  // 射極接地線
    o.push(res(X, 96, X, 40, 'r', true)); o.push(T(X - 14, 100, 'e', 10, 'font-family="Georgia,serif"'));
    o.push(L(X, 96, X, 40));
    o.push(res(X + 60, 40, X + 60, 130, 'r', true)); o.push(T(X + 74, 68, 'π', 10, 'font-family="Georgia,serif"'));
    o.push(L(X + 60, 40, X + 60, 40));
    o.push(dot(X, 40)); o.push(dot(X + 60, 40));
    o.push(dot(X, 130)); o.push(dot(X, 130));
    // 受控電流源 g_m v_π（菱形）
    o.push(`<circle cx="${X + 96}" cy="${X ? 0 : 0}" r="0"></circle>`);
    const y0 = 90;
    o.push(`<polygon points="${X + 96},70 ${X + 116},90 ${X + 96},110 ${X + 76},90" fill="none" stroke="#23272f" stroke-width="1.4"/>`);
    o.push(L(X + 96, 40, X + 96, 70)); o.push(L(X + 96, 110, X + 96, 130));
    o.push(`<polygon points="${X + 96},126 ${X + 91},116 ${X + 101},116" fill="#23272f"/>`);
    o.push(T(X + 122, 86, 'g', 11, 'font-family="Georgia,serif"') + T(X + 132, 92, 'm', 8, 'font-family="Georgia,serif"') + it(X + 140, 86, 'v', '') + T(X + 150, 90, 'π', 8, 'font-family="Georgia,serif"'));
    if (withRB) {
      o.push(L(X - 20, 40, X, 40)); o.push(dot(X, 40));
      o.push(res(X - 20, 40, X - 20, 90, 'R', true)); o.push(T(X - 6, 94, 'B', 10, 'font-family="Georgia,serif"'));
      o.push(L(X - 20, 90, X - 20, 130)); o.push(gl(X - 20, 130));
      o.push(L(X - 20, 40, X - 20, 40));
    }
    o.push(res(X + 40, 130, X + 40, 172, 'R', true)); o.push(T(X + 54, 176, 'E', 10, 'font-family="Georgia,serif"'));
    o.push(L(X, 130, X + 40, 130)); o.push(dot(X, 130));
    o.push(L(X + 40, 172, X + 40, 178)); o.push(gl(X + 40, 178));
    o.push(`<text x="${X}" y="212" font-size="11" font-style="italic" fill="#23272f">${title}</text>`);
    return `<g>${o.join('')}</g>`;
  }
  return { w1, w2 };
};
